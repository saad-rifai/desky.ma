# topbar

Site-wide progress indicator that is:

- Tiny (1KB minified and gzipped), no dependency
- Perfect for single-page applications
- Responsive

Check out [demo & usages](http://buunguyen.github.io/topbar).

MIT license. Copyright 2021 Buu Nguyen.
